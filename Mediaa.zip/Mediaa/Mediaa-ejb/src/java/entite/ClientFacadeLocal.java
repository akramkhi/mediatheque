/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entite;

import java.util.List;
import javax.ejb.Local;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

/**
 *
 * @author akram
 */
@Local
public interface ClientFacadeLocal {

    void create(Client client);

    void edit(Client client);

    void remove(Client client);

    Client find(Object id);
    public String generate(int length) ;
public void Send_mail(String nom,String prenom,String email,String pass);    
    List<Client> FindId(Object id);

    List<Client> findAll();

    List<Client> findRange(int[] range);

    int count();
    
    void create(String nom_client,String prenom_client,String adresse_client,boolean mode,String email,String md_pass);
    void update_nom(Integer id_client, String nom);
    void update_prenom(Integer id_client, String prenom);
    void update_email(Integer id_client, String email);
    void update_pass(Integer id_client, String pass);
    void sup_client(Object id);
    
    int valid_email(String email);
    
}
