/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entite;

import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author akram
 */
@Stateless
public class MessageFacade extends AbstractFacade<Messagee> implements MessageFacadeLocal {

    @PersistenceContext(unitName = "Mediaa-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public MessageFacade() {
        super(Messagee.class);
    }
    
    @Override
    public void create(String email,String nom,String prenom,Date date,String sujet,String message){
        String s="insert into message(email,nom,prenom,date,sujet,message) values ("+email+","+nom+","+prenom+","+date+","+sujet+","+message+")";
         em.createNativeQuery(s).executeUpdate();
    }
    
    @Override
    public void sup_msg(Object id){
        String s="delete from Messagee m where m.id="+id;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
        em.createNativeQuery(s).executeUpdate();
    }
    
    
         @Override
    public void edit(Messagee message) {
        em.merge(message);
    }

    @Override
    public void remove(Messagee message) {
        em.remove(em.merge(message));
    }

     @Override
    public Messagee find(Object id){
        return em.find(Messagee.class, id);
    }
   
    
}
