/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entite;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author akram
 */
@Stateless
public class ProduitFacade extends AbstractFacade<Produit> implements ProduitFacadeLocal {

    @PersistenceContext(unitName = "Mediaa-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ProduitFacade() {
        super(Produit.class);
    }
    
    @Override
     public void create(String id_produit,String libelle_produit,String id_type){
        String a="insert into produit(id_produit,libelle_produit,id_type)";
        a+="values ("+id_produit+","+libelle_produit+","+id_type+")";
        em.createNativeQuery(a).executeUpdate();
    }
    @Override 
    public void update_libelle(String id_produit, String libelle_produit){
         String s = "update produit set libelle_produit = " + libelle_produit
                + " where id_produit = '" + id_produit + "'";
        em.createNativeQuery(s).executeUpdate();
     }
  /*  @Override
    public List<String> findall(){
               
        return em.createNativeQuery(
                "select Produit.id_produit,Produit.libelle_produit,Type libelle_type"
                + "from Produit,Type"
                + "where Produit.id_type =:Type.id_type"
       ).executeUpdate();
        
    }
    */
   /* @Override 
    public void update_type(String id_produit, String id_type){
         String s = "update produit set id_type = " + id_type
                + " where id_produit = '" + id_produit + "'";
        em.createNativeQuery(s).executeUpdate();
     }
    */
     @Override
    public void edit(Produit produit) {
        em.merge(produit);
    }

    @Override
    public void remove(Produit produit) {
        em.remove(em.merge(produit));
    }

    @Override
    public Produit find(Object id) {
        return em.find(Produit.class, id);
    }

    @Override
    public List<Produit> findAll() {
        return em.createNamedQuery("Produit.findAll").getResultList();
    }
    @Override
    public List<Object> list_media(){
         String s="select id_produit,produit.id_type,libelle_produit,libelle_type from produit,type where produit.id_type=type.id_type ";                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
      return  em.createNativeQuery(s).getResultList();
   
    }
    @Override
    public int valid_media(Object id){
        String s = "select * from produit where id_produit="+id;
       return em.createNativeQuery(s).getFirstResult();
        
    }
    
}
