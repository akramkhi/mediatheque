/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entite;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author akram
 */
@Stateless
public class ClientFacade extends AbstractFacade<Client> implements ClientFacadeLocal {

    @PersistenceContext(unitName = "Mediaa-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ClientFacade() {
        super(Client.class);
    }
    
    @Override
    public void create(String nom_client,String prenom_client,String adresse_client,boolean mode,String email,String md_pass){
        String c="insert into client(id_client,nom_client,prenom_client,adresse_client,mode,email,md_pass";
        c+="values("+nom_client+","+prenom_client+","+adresse_client+","+mode+","+email+","+md_pass+")";
        em.createNativeQuery(c).executeUpdate();
    }
     @Override
    public void edit(Client client) {
        em.merge(client);
    }

    @Override
    public void remove(Client client) {
        em.remove(em.merge(client));
    }

     @Override
    public Client find(Object id){
        return em.find(Client.class, id);
    }
    @Override
    public List<Client> FindId(Object id){
        Query query = em.createQuery("SELECT c FROM Client c WHERE c.idClient = '"+id +"'"); 
          List<Client> c = query.getResultList() ;
          return c;
    }
   
   /*  @Override
    public Client findEm(Object email) {
        return em.find(Client.class, email);
    }
*/
    @Override
    public List<Client> findAll() {
    return em.createNamedQuery("Client.findAll").getResultList();   
    }
     /*@Override
    public Client findAll(String email, String pass) {
    return em.createNamedQuery("Client.conx").getParameterValue(param);   
    }*/
    
    
    
    
     
    @Override
    public void update_nom(Integer id_client, String nom) {
        String s = "update client set nom_client = " + nom
                + " where id_client = '" + id_client + "'";
        em.createNativeQuery(s).executeUpdate();
    }
    @Override
    public void update_prenom(Integer id_client, String prenom) {
        String s = "update client set prenom_client = " + prenom
                + " where id_client = '" + id_client + "'";
        em.createNativeQuery(s).executeUpdate();
    }
    @Override
    public void update_email(Integer id_client, String email) {
        String s = "update client set email = " + email
                + " where id_client = '" + id_client + "'";
        em.createNativeQuery(s).executeUpdate();
    }
    @Override
    public void update_pass(Integer id_client, String pass) {
        String s = "update client set md_pass = " + pass
                +" where id_client = " + id_client + ";";
        em.createNativeQuery(s).executeUpdate();
    }
    @Override
    public void sup_client(Object id){
        String s ="delete from client  where id_client="+id;
        em.createNativeQuery(s).executeUpdate();

    }
    
    @Override
    public int valid_email(String email){
    String s = "select * from client where email="+email;
       return em.createNativeQuery(s).getFirstResult();
        
       
    }
    public String generate(int length) {
	    String chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"; // Tu supprimes les lettres dont tu ne veux pas
	    String pass = "";
	    for(int x=0;x<length;x++)   {
	       int i = (int)Math.floor(Math.random() * chars.length() -1); // Si tu supprimes des lettres tu diminues ce nb
	       pass += chars.charAt(i);
	    }
	    System.out.println(pass);
	    return pass;
    }
    
    @Override
    public void Send_mail(String nom,String prenom,String email,String pass){
        Properties properties = new Properties();
        properties.setProperty("mail.transport.protocol", "smtps");
        properties.setProperty("mail.smtp.host", "smtp.gmail.com");
        properties.setProperty("mail.smtp.user", "mediaa.akram");
        properties.setProperty("mail.smtp.starttls.enable", "true");
        Session session = Session.getInstance(properties);
// 2 -> Création du message
        MimeMessage message = new MimeMessage(session);
        try{
        message.setFrom(new InternetAddress("mediaa.akram@gmail.com"));
        message.addRecipients(Message.RecipientType.TO, email);
        message.setSubject("Media-Akram-Ahmed");
        message.setText("Bonjour  <b> "+nom+" "+prenom+"</b><br>"+
                " Bienvenue dans <b>Media-akram-Ahmed</b><br>"
                + "Vos informations de connexion sont désormais : <br>"
                + "Email : "+email+"<br>"
                + "Mot de pass : "+pass+"<br>"
                +"Si vous avez besoin d'aide, veuillez contacter l'administrateur du site <b>Media-Akram-Ahmed<b> : ------@gmail.com <br>" 
                +"***Ceci est message automatique. Merci de ne pas répondre!***"
                ,"utf-8", "html");
        }catch (Exception e){
            
        }
        Transport transport = null;
        try {
            transport = session.getTransport("smtps");
            transport.connect("smtp.gmail.com", "mediaa.akram@gmail.com", "media1234");
            List<InternetAddress> adresses = new ArrayList();
            adresses.add(new InternetAddress(email));
            Address[] adressesTab = new Address[adresses.size()];
            adressesTab = adresses.toArray(adressesTab);
            transport.sendMessage(message, adressesTab);
        } catch (MessagingException e) {
            e.printStackTrace();
        } finally {
            if (transport != null) {
                try {
                    transport.close();
                } catch (MessagingException ex) {
                    Logger.getLogger(ClientFacade.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
 

    
      
      
    
}