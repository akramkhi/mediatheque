/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entite;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import static jdk.nashorn.internal.runtime.Debug.id;

/**
 *
 * @author akram
 */
@Stateless
public class PreterFacade extends AbstractFacade<Preter> implements PreterFacadeLocal {

    
    @PersistenceContext(unitName = "Mediaa-ejbPU")
    private EntityManager em;
  

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PreterFacade() {
        super(Preter.class);
    }
    @Override
     public void create(Integer id_client,String id_produit,Date datePr,Date dateRetour){
        String s = "insert into preter(id_client,id_produit,datePr,dateRetour)";
        s+="values ("+id_client+","+id_produit+","+datePr+","+dateRetour+")";
        em.createNativeQuery(s).executeUpdate();
        
    }
     @Override
     public List<Object> list_emp (){
         
          Query query = em.createNativeQuery("select client.id_client,client.nom_client,client.prenom_client,produit.id_produit,produit.LIBELLE_PRODUIT,DATE_PR,DATE_RETOUR from client,produit,preter where (preter.ID_CLIENT=CLIENT.ID_CLIENT) and (PRETER.ID_PRODUIT=PRODUIT.ID_PRODUIT)"); 
         
         return  query.getResultList() ;
     }
    
     @Override
     public List<Object> verifier_date(){
     
         Query query = em.createNativeQuery("select id_client from preter where (date_pr>date_retour)"); 
         return  query.getResultList() ;

     }
     @Override
     public List<Object> client_emp(Object id){
         
          Query query = em.createNativeQuery("select produit.libelle_produit,preter.id_produit,date_pr,date_retour from preter,produit where preter.id_produit=produit.id_produit and id_client="+id); 
         return  query.getResultList() ;
     }
      @Override
     public void supprimer_emp(Integer id,String id_produit){
         
            String s = "delete from preter where (id_client="+id+") and (id_produit='"+id_produit+"')";
         em.createNativeQuery(s).executeUpdate();
     }
     
  
     
    
}
