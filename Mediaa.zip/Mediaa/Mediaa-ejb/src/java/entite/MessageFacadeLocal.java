/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entite;

import java.util.Date;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author akram
 */
@Local
public interface MessageFacadeLocal {

    void create(Messagee message);

    void edit(Messagee message);

    void remove(Messagee message);
    void create(String email,String nom,String prenom,Date date,String sujet,String message);
    void sup_msg(Object id);
    Messagee find(Object id);

    List<Messagee> findAll();

    List<Messagee> findRange(int[] range);

    int count();
    
}
