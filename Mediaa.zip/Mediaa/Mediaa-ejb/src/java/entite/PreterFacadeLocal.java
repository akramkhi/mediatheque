/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entite;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author akram
 */
@Local
public interface PreterFacadeLocal {

    void create(Preter preter);

    void edit(Preter preter);
    void supprimer_emp(Integer id,String id_produit);
    void remove(Preter preter);

    Preter find(Object id);

    List<Preter> findAll();

    List<Preter> findRange(int[] range);

    int count();
    
   void create(Integer id_client,String id_produit,Date datePr,Date dateRetour);
   
    List<Object> verifier_date();
    List<Object> list_emp ();
    List<Object> client_emp(Object id);
    
}
