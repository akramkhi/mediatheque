/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entite;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author akram
 */
@Stateless
public class TypeFacade extends AbstractFacade<Type> implements TypeFacadeLocal {

    @PersistenceContext(unitName = "Mediaa-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public TypeFacade() {
        super(Type.class);
    }
    
    
    @Override
     public void create(String id_type,String libelle_type){
        String t="insert into type(id_type,libelle_type)";
        t+="values("+id_type+","+libelle_type+")";
        em.createNativeQuery(t).executeUpdate();
    }
    /*
    public void update_id(Type type ,String id_type) {
        String s = "update type set id_type = " + id_type
                + " where id_type = '" + type.getIdType() + "'";
        em.createNativeQuery(s).executeUpdate();
    }
*/
    public void update_libelle(String id_type, String libelle) {
        String s = "update type set libelle_type = " + libelle
                + " where id_type = '" + id_type + "'";
        em.createNativeQuery(s).executeUpdate();
    }

 @Override
    public void edit(Type type) {
        em.merge(type);
    }

    @Override
    public void remove(Type type ){
        em.remove(em.merge(type));
    }

    @Override
    public Type find(Object id) {
        return em.find(Type.class, id);
    }

    @Override
    public List<Type> findAll() {
        return em.createNamedQuery("Type.findAll").getResultList();
    }
}
