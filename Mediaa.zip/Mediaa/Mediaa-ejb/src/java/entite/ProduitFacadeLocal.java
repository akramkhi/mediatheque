/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entite;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author akram
 */
@Local
public interface ProduitFacadeLocal {

    void create(Produit produit);
    
    void create(String id_produit,String libelle_produit,String id_type);

    void edit(Produit produit);

    void remove(Produit produit);

    Produit find(Object id);

    List<Produit> findAll();

    List<Produit> findRange(int[] range);
     List<Object> list_media();

    int count();
    
    //void update_type(String id_produit, String id_type);
    void update_libelle(String id_produit, String libelle_produit);
    int valid_media(Object id);
    
}
