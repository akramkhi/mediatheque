/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entite;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author akram
 */
@Entity
@Table(name = "PRETER")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Preter.findAll", query = "SELECT p FROM Preter p")
    , @NamedQuery(name = "Preter.findByIdClient", query = "SELECT p FROM Preter p WHERE p.preterPK.idClient = :idClient")
    , @NamedQuery(name = "Preter.findByIdProduit", query = "SELECT p FROM Preter p WHERE p.preterPK.idProduit = :idProduit")
    , @NamedQuery(name = "Preter.findByDatePr", query = "SELECT p FROM Preter p WHERE p.datePr = :datePr")
    , @NamedQuery(name = "Preter.findByDateRetour", query = "SELECT p FROM Preter p WHERE p.dateRetour = :dateRetour")})
public class Preter implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected PreterPK preterPK;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DATE_PR")
    @Temporal(TemporalType.DATE)
    private Date datePr;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DATE_RETOUR")
    @Temporal(TemporalType.DATE)
    private Date dateRetour;
    @JoinColumn(name = "ID_CLIENT", referencedColumnName = "ID_CLIENT", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Client client;
    @JoinColumn(name = "ID_PRODUIT", referencedColumnName = "ID_PRODUIT", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Produit produit;

    public Preter() {
    }

    public Preter(PreterPK preterPK) {
        this.preterPK = preterPK;
    }

    public Preter(PreterPK preterPK, Date datePr, Date dateRetour) {
        this.preterPK = preterPK;
        this.datePr = datePr;
        this.dateRetour = dateRetour;
    }

    public Preter(int idClient, String idProduit) {
        this.preterPK = new PreterPK(idClient, idProduit);
    }

    public PreterPK getPreterPK() {
        return preterPK;
    }

    public void setPreterPK(PreterPK preterPK) {
        this.preterPK = preterPK;
    }

    public Date getDatePr() {
        return datePr;
    }

    public void setDatePr(Date datePr) {
        this.datePr = datePr;
    }

    public Date getDateRetour() {
        return dateRetour;
    }

    public void setDateRetour(Date dateRetour) {
        this.dateRetour = dateRetour;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Produit getProduit() {
        return produit;
    }

    public void setProduit(Produit produit) {
        this.produit = produit;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (preterPK != null ? preterPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Preter)) {
            return false;
        }
        Preter other = (Preter) object;
        if ((this.preterPK == null && other.preterPK != null) || (this.preterPK != null && !this.preterPK.equals(other.preterPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entite.Preter[ preterPK=" + preterPK + " ]";
    }
    
}
