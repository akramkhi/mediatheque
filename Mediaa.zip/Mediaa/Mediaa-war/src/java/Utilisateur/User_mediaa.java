/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utilisateur;

import entite.Client;
import entite.ClientFacadeLocal;
import entite.Preter;
import entite.PreterFacadeLocal;
import entite.ProduitFacadeLocal;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author akram
 */
public class User_mediaa extends HttpServlet {

    @EJB
    private ProduitFacadeLocal produitFacade;

    @EJB
    private ClientFacadeLocal clientFacade;

    @EJB
    private PreterFacadeLocal preterFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("name");
        PrintWriter out= response.getWriter();
        
        /////////////////////////////////////////////////
        if(action.equals("sedeconnecter")){
                HttpSession session = request.getSession();
                session.invalidate();
                response.sendRedirect("index.jsp");
        }
        //////////////////////////////////////////
        if(action.equals("emp_utilisateur")){
            String id = request.getParameter("id");
            List<Object> p= preterFacade.client_emp(id);
            if(p.isEmpty()){
                String error_emp=" <div style='width:500px;' class='alert alert-warning alert-dismissible'>"+
               " <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>"+
               " <h4><i class='icon fa fa-warning'></i> Oops!</h4>"+
               "Vous n'avez pas des emprunts"+
                    "</div>";
                    request.setAttribute("error_emp", error_emp);
                RequestDispatcher dp = request.getRequestDispatcher("emp_client.jsp");  
                 dp.forward(request, response);  
            }else{
                request.setAttribute("emp", p);
                RequestDispatcher dp = request.getRequestDispatcher("emp_client.jsp");  
                 dp.forward(request, response);  
                
            }
           } 
        ////////////////////////////////////////////////////////
        if(action.equals("liste_media")){
               List<Object> list=produitFacade.list_media();
                
                 request.setAttribute("list",list);  
                 RequestDispatcher dp = request.getRequestDispatcher("list_media_client.jsp");  
                 dp.forward(request, response);  

        }
        /////////////////////////////////////
        if(action.equals("index_utilisateur")){
            response.sendRedirect("index_utilisateur.jsp");
        }
           
            
            
        
    }


    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
