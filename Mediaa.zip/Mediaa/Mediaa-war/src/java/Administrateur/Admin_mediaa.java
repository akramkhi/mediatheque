/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Administrateur;

import entite.ClientFacadeLocal;
import entite.PreterFacadeLocal;
import entite.*;
import entite.ProduitFacadeLocal;
import entite.TypeFacadeLocal;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;

import javax.inject.Named;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 *
 * @author akram
 */
@Named(value="admin_media")
public class Admin_mediaa extends HttpServlet {

    @EJB
    private MessageFacadeLocal messageFacade;

    @EJB
    private TypeFacadeLocal typeFacade;

    @EJB
    private ProduitFacadeLocal produitFacade;

    @EJB
    private PreterFacadeLocal preterFacade;

    @EJB
    private ClientFacadeLocal clientFacade;

   
    /*
    <%  if(request.getAttribute("type")=null) {  
        response.sendRedirect("Admin_mediaa?name=ajouter_media");
        } %>    pour le rechargement des listes 
  */ 
  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("name");
        PrintWriter out = response.getWriter();
        ///////////////////////////////////////////
        if(action.equals("index_admin")){
            try{
             int count_client=clientFacade.count();
                    int count_type=typeFacade.count();
                    int count_emp=preterFacade.count();
                    int count_media=produitFacade.count();
                    int count_msg=messageFacade.count();
                    request.setAttribute("count_client", count_client);
                    request.setAttribute("count_emp", count_emp);
                    request.setAttribute("count_type", count_type);
                    request.setAttribute("count_media", count_media);
                    request.setAttribute("count_msg", count_msg);
                     RequestDispatcher dp = request.getRequestDispatcher("index_admin.jsp");  
                 dp.forward(request, response); 
            }catch(Exception e){
                    out.print("Sorry ");
            }
        }
        
        //////////////////////////////////////////////////
        if(action.equals("gestion_client")){
            List<Client> list_client = clientFacade.findAll();
                 request.setAttribute("list_client",list_client);  
                 RequestDispatcher dp;  
                     dp = request.getRequestDispatcher("client.jsp");
                 dp.forward(request, response);  
      
            }
        //////////////////////////////////////////////////
        if(action.equals("seconnecter")){
            RequestDispatcher dp = request.getRequestDispatcher("index.jsp");  
                 dp.forward(request, response);   
                
        }
        //////////////////////////////////////////////////
        if(action.equals("sedeconnecter")){
                HttpSession session = request.getSession();
                session.invalidate();
                response.sendRedirect("index.jsp");
        }
       ////////////////////////////////////////////////////////
       
          if(action.equals("listmedia")){ //// liste media 
                
                List<Object> list=produitFacade.list_media();
                request.setAttribute("list",list);  
                RequestDispatcher dp = request.getRequestDispatcher("list_media_1.jsp");  
                dp.forward(request, response);  

            }
          ///////////////////////////////////////////////////////////////
          if(action.equals("ajouter_client")){ 
               response.sendRedirect("ajouter_client.jsp");
            }
          ///////////////////////////////////////////////////////////////
          if(action.equals("supprimer_client")){
           
             String rm = request.getParameter("val");
             clientFacade.sup_client(rm);
             RequestDispatcher dp = request.getRequestDispatcher("Admin_mediaa?name=gestion_client");  
                 dp.forward(request, response);  
              }
          //////////////////////////////////////////////////////////////
            if(action.equals("gestion_type")){
                 List<Type> list = typeFacade.findAll();
                 request.setAttribute("list_type",list);  
                 RequestDispatcher dp = request.getRequestDispatcher("type.jsp");  
                 dp.forward(request, response);  
                 }
             //////////////////////////////////////////////////////////
             if(action.equals("ajouter_type")){
                 response.sendRedirect("ajouter_type.jsp");
             }
             ////////////////////////////////////////////////////////////
             if(action.equals("liste_emprunte")){
               
                 List<Object> list_emp = preterFacade.list_emp();
                request.setAttribute("list_emp", list_emp);
                  RequestDispatcher dp = request.getRequestDispatcher("emprunte.jsp");  
                 dp.forward(request, response); 
             }
             
             //////////////////////////////////////////////////////////////
             if(action.equals("ajouter_emp")){
                 List<Produit> p = produitFacade.findAll();
                 List<Client> c = clientFacade.findAll();
                 request.setAttribute("client", c);
                 request.setAttribute("produit", p);
                  RequestDispatcher dp = request.getRequestDispatcher("ajouter_emp.jsp");  
                 dp.forward(request, response);  
             }
             ///////////////////////////////////////////////////////
             if(action.equals("ajouter_media")){
                 String msg_error=request.getParameter("msg_media");
                 String msg_ok=request.getParameter("msg_okk");
                 List<Type> t = typeFacade.findAll();
                 request.setAttribute("msg_media", msg_error);
                 request.setAttribute("msg_okk", msg_ok);
                 request.setAttribute("type", t);

                  RequestDispatcher dp = request.getRequestDispatcher("ajouter_media.jsp");  
                 dp.forward(request, response);  
             }
             ///////////////////////////////////////////////////////
             if(action.equals("modifier_type"))
             {
                 String id=request.getParameter("id");
                 out.println(id);
             }
             /////////////////////////////////////////////////////////////
             if(action.equals("messagerie")){
                
                 List<Messagee> m=messageFacade.findAll();
                 if(!m.isEmpty()){
                 request.setAttribute("message", m);
                  RequestDispatcher dp = request.getRequestDispatcher("messagerie.jsp");  
                 dp.forward(request, response);  
                 }
                 else{
                    String mm=" <div style='width:500px;' class='alert alert-warning alert-dismissible'>"+
               " <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>"+
               " <h4><i class='icon fa fa-warning'></i> Oops!</h4>"+
               "la messagerie est vide "+
                    "</div>";
                     
                     request.setAttribute("message_error", mm);
                  RequestDispatcher dp = request.getRequestDispatcher("messagerie.jsp");  
                 dp.forward(request, response);  
                 }
             }
             ////////////////////////////////////////////////////////////////////
             if(action.equals("supprimer_msg")){
                String id=request.getParameter("id");
              
               messageFacade.sup_msg(id);
               String sup_ok=" ";
               request.setAttribute("sup_ok", sup_ok);
                  RequestDispatcher dp = request.getRequestDispatcher("messagerie.jsp");  
                 dp.forward(request, response);  
             }
             ///////////////////////////////////////////////////////////////////
             if(action.equals("supprimer_type")){
                 try{
                    String id=request.getParameter("id");
                    Type t =typeFacade.find(id);
                    typeFacade.remove(t);
                     RequestDispatcher dp = request.getRequestDispatcher("type.jsp");  
                 dp.forward(request, response);  
                 }catch(IOException | ServletException e){
                     RequestDispatcher dp = request.getRequestDispatcher("type.jsp");  
                 dp.forward(request, response); 
                 }
             }
             
             ///////////////////////////////////////
             if(action.equals("modifier_client")){
                 String id=request.getParameter("val");
                 Client a=null;
                 List<Client> c = clientFacade.FindId(id);
                if(!c.isEmpty()){
                   a=c.get(0);
                   request.setAttribute("client", a);
                   //out.print(a.);
                   RequestDispatcher dp = request.getRequestDispatcher("modifier_client.jsp");  
                 dp.forward(request, response);  
                   
                   }
             }
             /////////////////////////////////////////////////
             if(action.equals("supprimer_media")){
                 String id=request.getParameter("id");
                 Produit p = produitFacade.find(id);
                 produitFacade.remove(p);
                    RequestDispatcher dp = request.getRequestDispatcher("list_media_1.jsp");  
                 dp.forward(request, response);  
             }
             ///////////////////////////////////////////////////////////
             if(action.equals("modifier_media")){
                  String id=request.getParameter("id");
             Produit p = produitFacade.find(id);
            List<Type> t = typeFacade.findAll();
            request.setAttribute("type", t);
             request.setAttribute("media", p);
              RequestDispatcher dp = request.getRequestDispatcher("modifier_media.jsp");  
                 dp.forward(request, response);  
             }
             //////////////////////////////////////////////////////////////
             if(action.equals("supprimer_emp")){
                 String id_client=request.getParameter("id_client");
                 Integer idclient=Integer.parseInt(id_client);
                 String id_produit=request.getParameter("id_produit");
                 preterFacade.supprimer_emp(idclient, id_produit);
                 response.sendRedirect("emprunte.jsp");
                 
             }
             
             //////////////////////////////////////////////////////////////
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        String action = request.getParameter("name");
//////////////////////////////////////////////////////////////////////////////         
        if ( action.equals("ajouter_client")){
         String nom_client = request.getParameter("nom");
        String prenom_client = request.getParameter("prenom");
        String adresse_client = request.getParameter("adresse");
        String mod =request.getParameter("mode");
        String email = request.getParameter("email");
         
         if ( nom_client.trim().isEmpty() || prenom_client.trim().isEmpty() || adresse_client.trim().isEmpty() || mod.trim().isEmpty()  || email.trim().isEmpty()) {

           String  msg_error = "<b>Erreur - </b> Vous n'avez pas rempli tous les champs obligatoires. ";
           request.setAttribute("msg_error",msg_error);  
           RequestDispatcher dp = request.getRequestDispatcher("ajouter_client.jsp");  
            dp.forward(request, response);  
              }else {
             List<Client> client = clientFacade.findAll();
                boolean ok=false;
             for (Client c : client) {
                if(c.getEmail().equals(email) ){
                    ok=true;
                 break;
                } 
            }
             
            if(ok==true){
                String  msg_error = "<b>Erreur - </b> L'email existe déja. ";
                request.setAttribute("msg_error",msg_error);  
                RequestDispatcher dp = request.getRequestDispatcher("ajouter_client.jsp");  
                 dp.forward(request, response);  
            } else {
             boolean mode = Boolean.parseBoolean(mod);
            String  msg_ok = "<b>Succes -</b>Le client a été bien crée ";
            try{
        Client nouveau_client = new Client();
        nouveau_client.setNomClient(nom_client);
        nouveau_client.setPrenomClient(prenom_client );
        nouveau_client.setAdresseClient(adresse_client);
        nouveau_client.setMode(mode);
        nouveau_client.setEmail(email);
        String pass = clientFacade.generate(10);
        nouveau_client.setMdPass(pass);
        clientFacade.create(nouveau_client);
        clientFacade.Send_mail(nouveau_client.getNomClient(),nouveau_client.getPrenomClient(),nouveau_client.getEmail(), nouveau_client.getMdPass());
        request.setAttribute("msg_ok",msg_ok);  
        RequestDispatcher dp = request.getRequestDispatcher("ajouter_client.jsp");  
        dp.forward(request, response);    
            
            }catch(Exception e){
                 String  msg_error = "Erreur - Veuillez refaire à nouveau";
           request.setAttribute("msg_error",msg_error);  
           RequestDispatcher dp = request.getRequestDispatcher("ajouter_client.jsp");  
            dp.forward(request, response);  
            }
            
        }
        }
        }
       /////////////////////////////////////////////////////////////
        if(action.equals("seconnecter")){
            HttpSession session = request.getSession();
                String email=request.getParameter("email");
                String pass=request.getParameter("md_pass");
              List<Client> client = clientFacade.findAll();
                boolean ok=false;
                Client a = null;
            for (Client c : client) {
                if(c.getEmail().equals(email) && c.getMdPass().equals(pass)){
                    ok=true;
                    a=c;
                 break;
                } 
            }
                if ( ok==true){
                    if(a.getMode()==true){
                    session.setAttribute("client",a);
                    int count_client=clientFacade.count();
                    int count_type=typeFacade.count();
                    int count_emp=preterFacade.count();
                    int count_media=produitFacade.count();
                    int count_msg=messageFacade.count();
                    request.setAttribute("count_client", count_client);
                    request.setAttribute("count_emp", count_emp);
                    request.setAttribute("count_type", count_type);
                    request.setAttribute("count_media", count_media);
                    request.setAttribute("count_msg", count_msg);
                     RequestDispatcher dp = request.getRequestDispatcher("index_admin.jsp");  
                    dp.forward(request, response); 
                             }else{
                                       session.setAttribute("utilisateur",a);
                         RequestDispatcher dp = request.getRequestDispatcher("index_utilisateur.jsp");  
                         dp.forward(request, response); 
                    }
                }
                    else{
                    String msg=" <strong>Dézole!</strong> Veuillez retaper l'email et le mot de pass.";
                 request.setAttribute("error_cnx",msg);  
                 RequestDispatcher dp = request.getRequestDispatcher("index.jsp");  
                 dp.forward(request, response);  
                 
                }
   
    }
        ////////////////////////////////////////////////////////////////////////
        
         if(action.equals("add_type")){
             
         String id_type = request.getParameter("id_type");
        String libelle_type = request.getParameter("libelle_type");
        String msg_type=null;
        String msg_ok=null;
        if ( id_type.trim().isEmpty() || libelle_type.trim().isEmpty())  {

            msg_type= "Erreur - Vous n'avez pas rempli tous les champs obligatoires. ";
              request.setAttribute("msg_type", msg_type);
            RequestDispatcher dp = request.getRequestDispatcher("ajouter_type.jsp");  
                 dp.forward(request, response);  
        } else {
                Type type = new Type();
                type.setIdType(id_type);
                type.setLibelleType(libelle_type);
                 typeFacade.create(type);
               msg_ok ="<strong>Succes!</strong> Le type a été ajouteé.";
                request.setAttribute("msg_ok", msg_ok);
                 RequestDispatcher dp = request.getRequestDispatcher("ajouter_type.jsp");  
                 dp.forward(request, response);  
                 
             }
      
        }
       ///////////////////  /////////////////////////////////////////////
         if(action.equals("add_media")){
             String id_media=request.getParameter("id_media");
             String libelle_media=request.getParameter("libelle_media");
            String id_type=request.getParameter("id_type");
             String msg=null;
             if ( id_media.trim().isEmpty() || libelle_media.trim().isEmpty() )  {

            msg= "Erreur - Vous n'avez pas rempli tous les champs obligatoires. ";
              request.setAttribute("msg_media", msg);
            RequestDispatcher dp = request.getRequestDispatcher("ajouter_media.jsp");  
                 dp.forward(request, response);  
             }else{
                 int v=produitFacade.valid_media(id_media);
                 if(v>0){
                       msg= "Erreur - L'id de ce media existe déja. ";
                    request.setAttribute("msg_media", msg);
                  RequestDispatcher dp = request.getRequestDispatcher("ajouter_media.jsp");  
                       dp.forward(request, response); 
                     
                 } else{
                 Type t=typeFacade.find(id_type);
                 Produit p = new Produit();
                 p.setIdProduit(id_media);
                 p.setLibelleProduit(libelle_media);
                 p.setIdType(t);
                 produitFacade.create(p);
                 msg="L'ajout a été bien fait";
                 request.setAttribute("msg_okk", msg);
                 RequestDispatcher dp = request.getRequestDispatcher("ajouter_media.jsp");  
                 dp.forward(request, response);  
             }
        
             }
             
         }
         //////////////////////////////////////////////////////////////
         if(action.equals("add_emp")){
             String id_client= request.getParameter("id_client");
             String id_produit = request.getParameter("id_media");
             String d=request.getParameter("date_retour");
             
              if ( id_client.trim().isEmpty() || id_produit.trim().isEmpty() || d.trim().isEmpty() )  {

            String msg= "Erreur - Vous n'avez pas rempli tous les champs obligatoires. ";
              request.setAttribute("msg_error_emp", msg);
               RequestDispatcher dp = request.getRequestDispatcher("ajouter_emp.jsp");  
                 dp.forward(request, response);  
              }
              else{
            SimpleDateFormat dt_rt= new SimpleDateFormat("dd/MM/yyyy");
            Date dt=new Date();
            String t=dt_rt.format(dt);
            //String aa= dt_rt.format(d);
            Date date_pr = null;
            Date date_retour=null;
            try {
               date_pr=dt_rt.parse(t);
               date_retour= dt_rt.parse(d);
            } catch (ParseException ex) {
                Logger.getLogger(Admin_mediaa.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
            if(date_retour.compareTo(date_pr ) == -1){
                   String msg= "Erreur - Vous avez  rempli une date inferieure à la date d'aujourd'huit";
              request.setAttribute("msg_error_emp", msg);
               RequestDispatcher dp = request.getRequestDispatcher("ajouter_emp.jsp");  
                 dp.forward(request, response);  
                
            }else{
         Client a = null;
           List<Client> c = clientFacade.FindId(id_client);
          if(!c.isEmpty()){
             a=c.get(0);
             
            
          }
         
           PreterPK key = new PreterPK();
           key.setIdClient(a.getIdClient());
           key.setIdProduit(id_produit);
           
           Preter pr= new Preter();
             Produit p = produitFacade.find(id_produit);
           
           pr.setClient(a);
           pr.setProduit(p);
           pr.setPreterPK(key);
           pr.setDatePr(date_pr);
           pr.setDateRetour(date_retour);
           preterFacade.create(pr);
            String msg="L'ajout a été bien fait";
                 request.setAttribute("msg_ok_emp", msg);
                 RequestDispatcher dp = request.getRequestDispatcher("ajouter_emp.jsp");  
                 dp.forward(request, response);  
                 }
             }
         }
         
         ////////////////////////////////////////////////////////
         if(action.equals("editer_type")){
             String id=request.getParameter("id");
             String nv_lib=request.getParameter("lib_type");
            
            if ( !nv_lib.trim().isEmpty() )  {
                Type t=typeFacade.find(id);
                t.setLibelleType(nv_lib);
                typeFacade.edit(t);
                
              // typeFacade.update_libelle(id, nv_lib);
                 // String msg="La modification  a été bien fait";
                 //request.setAttribute("modif_ok", msg);
                 RequestDispatcher dp = request.getRequestDispatcher("type.jsp");  
                 dp.forward(request, response);  
                 
            }

         }
         
         ////////////////////////////////////////////////////////////
         if(action.equals("modifier_client")){
             String id = request.getParameter("id");
             String nom=request.getParameter("nom");
             String prenom=request.getParameter("prenom");
             String adresse=request.getParameter("adresse");
             String email=request.getParameter("email");
             String pass=request.getParameter("pass");
             
             List<Client> client = clientFacade.findAll();
                boolean ok=false;
                int count=0;
             for (Client c : client) {
                if(c.getEmail().equals(email) ){
                    ok=true;
                    count++;
                 break;
                } 
            }
          
            if((ok==true) && (count>1)){
                  String  msg_error = "<b>Erreur - </b> L'email existe déja. ";
                request.setAttribute("msg_error",msg_error);  
                RequestDispatcher dp = request.getRequestDispatcher("ajouter_client.jsp");  
                 dp.forward(request, response); 
             }else{
             List<Client> cl=clientFacade.FindId(id);
             Client a=null;
             if(!cl.isEmpty()){
                   a=cl.get(0);
             a.setNomClient(nom);
             a.setPrenomClient(prenom);
             a.setAdresseClient(adresse);
             a.setEmail(email);
             a.setMdPass(pass);
             clientFacade.edit(a);
                clientFacade.Send_mail(a.getNomClient(), a.getPrenomClient(), a.getEmail(), a.getMdPass());
               RequestDispatcher dp = request.getRequestDispatcher("client.jsp");  
                 dp.forward(request, response);  
             }
             }
         }
         /////////////////////////////
         if(action.equals("modifier_media")){
          String id_media= request.getParameter("id_media");
          String libelle= request.getParameter("libelle_media");
          String id_type = request.getParameter("id_type");
          if ( libelle.trim().isEmpty() )  {

            String msg= "Erreur - Vous n'avez pas rempli tous les champs obligatoires. ";
              request.setAttribute("msg_media", msg);
            RequestDispatcher dp = request.getRequestDispatcher("modifier_media.jsp");  
                 dp.forward(request, response);  
             }else{
              
              Produit p = produitFacade.find(id_media);
              Type t = typeFacade.find(id_type);
              out.println(p.getLibelleProduit());
              out.println(t.getLibelleType());
              p.setLibelleProduit(libelle);
              p.setIdType(t);
              produitFacade.edit(p);
              String msg="<b>Succes</b>- Media a été bien modifié. ";
               request.setAttribute("msg_okk", msg);
            RequestDispatcher dp = request.getRequestDispatcher("modifier_media.jsp");  
                 dp.forward(request, response);  
           }
         }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
