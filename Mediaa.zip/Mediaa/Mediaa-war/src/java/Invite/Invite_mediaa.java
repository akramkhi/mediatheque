/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Invite;

import entite.Client;
import entite.ClientFacadeLocal;
import entite.Messagee;
import entite.MessageFacadeLocal;
import entite.Produit;
import entite.ProduitFacadeLocal;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author akram
 */
public class Invite_mediaa extends HttpServlet {

    @EJB
    private MessageFacadeLocal messageFacade;

    @EJB
    private ClientFacadeLocal clientFacade;

    @EJB
    private ProduitFacadeLocal produitFacade;

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try{
            PrintWriter p =response.getWriter();
              String action = request.getParameter("name");
            
              
       
            if (action.equals("contact")) { // demande la page de contact 
                 p.print(action);
                  response.sendRedirect("contacte.jsp");
            
            }
            if(action.equals("listmedia")){ //// liste media 
                try{
                 List<Object> list = produitFacade.list_media();
                 request.setAttribute("list",list);  
                 RequestDispatcher dp = request.getRequestDispatcher("list_media.jsp");  
                 dp.forward(request, response);  
                }catch(Exception c){
                    p.print("we are sorry");
                }
            }
            if(action.equals("seconnecter")){
                response.sendRedirect("login.jsp");
            }
            
       
        }catch(IOException e ){
           
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          String action=request.getParameter("name");
          if(action.equals("contact_us")){
          String email=request.getParameter("email");
          String nom=request.getParameter("nom");
          String prenom=request.getParameter("prenom");
          String sujet=request.getParameter("sujet");
          String msg=request.getParameter("msg");
           if ( email.trim().isEmpty() || nom.trim().isEmpty() || prenom.trim().isEmpty() || msg.trim().isEmpty() || sujet.trim().isEmpty()) {
               String msg_error="<strong> Oops, </strong>Veuillez remplir tout les champs";
               request.setAttribute("msg_error", msg_error);
               RequestDispatcher dp = request.getRequestDispatcher("contacte.jsp");  
                 dp.forward(request, response);  
           }else{
                SimpleDateFormat dt_rt= new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
                 Date date=new Date();
                 String t=dt_rt.format(date);
                 Date dat=null;
              try {
                   dat=dt_rt.parse(t);
              } catch (ParseException ex) {
                  Logger.getLogger(Invite_mediaa.class.getName()).log(Level.SEVERE, null, ex);
              }
               Messagee ms=new Messagee();
               ms.setEmail(email);
               ms.setNom(nom);
               ms.setPrenom(prenom);
               ms.setDate(dat);
               ms.setMessage(msg);
               ms.setSujet(sujet);
               messageFacade.create(ms);
                 String msg_ok="Le message a été bien envoyé ";
               request.setAttribute("msg_ok", msg_ok);
               RequestDispatcher dp = request.getRequestDispatcher("contacte.jsp");  
                 dp.forward(request, response);  
               
                     
           }
                  }
           
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
